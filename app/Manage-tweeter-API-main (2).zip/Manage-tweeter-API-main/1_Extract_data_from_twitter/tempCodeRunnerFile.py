
print(base_dir)