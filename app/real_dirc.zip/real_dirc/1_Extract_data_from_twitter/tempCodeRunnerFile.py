
print(base_dir)