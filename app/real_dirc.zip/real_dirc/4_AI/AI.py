import json  
import pandas as pd


import os ,string
#path
from pathlib import Path
base_dir = Path(__file__).resolve().parent.parent
root=str(base_dir)+ "/"

df=pd.read_json(root+"Choose_Number_of_tweets_and_output_name.json")
file_path = root + 'prepared_'+df['fileName'][0]
output_name = root + 'final_'+df['fileName'][0]
with open(file_path, 'r', encoding='utf-8') as f: 
    data = json.load(f)



import sys
sys.path.append(root+'4_AI/camel_tools-master')
from camel_tools.sentiment import SentimentAnalyzer
sa = SentimentAnalyzer.pretrained()


new_data = []
for tweet in data:
    text = tweet.get("text", "").strip()
    if text:
        sentiment = sa.predict_sentence(text)
    else:
        sentiment = "unknown"
    
    tweet_with_sentiment = tweet.copy()
    tweet_with_sentiment["sentiment"] = sentiment
    new_data.append(tweet_with_sentiment)

# حفظ الملف الجديد
with open(output_name, 'w', encoding='utf-8') as f:
    json.dump(new_data, f, ensure_ascii=False, indent=2)

