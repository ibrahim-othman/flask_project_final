camel_tools.tagger
==================

.. automodule:: camel_tools.tagger

.. toctree::
   :maxdepth: 1
   :caption: Modules:

   tagger/common
   tagger/default
