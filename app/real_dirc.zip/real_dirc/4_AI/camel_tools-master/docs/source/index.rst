CAMeL Tools Documentation
=========================

.. image:: _static/camel_tools_logo.png

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   overview
   getting_started
   cli_tools
   api
   reference
   license



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
