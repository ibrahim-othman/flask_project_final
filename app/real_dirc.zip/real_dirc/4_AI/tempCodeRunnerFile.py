import sys
sys.path.append('./camel_tools-master')
from camel_tools.sentiment import SentimentAnalyzer
sa = SentimentAnalyzer.pretrained()