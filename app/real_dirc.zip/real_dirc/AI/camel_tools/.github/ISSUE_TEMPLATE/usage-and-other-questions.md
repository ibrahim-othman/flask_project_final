---
name: Usage and other questions
about: Ask for help understanding CAMeL Tools, how it works, and how to use it.
title: "[QUESTION] Title of question..."
labels: question
assignees: owo

---

**Describe what you would like to know about CAMeL Tools.**
This can be a question about a particular component, a general concept etc.

**If asking about a particular component, provide any previous attempts at using it.**
This will help us understand what you are trying to do.
