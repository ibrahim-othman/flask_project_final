Python API Reference
====================

.. toctree::
   :maxdepth: 2
   :titlesonly:
   :caption: Modules:

   api/utils
   api/data
   api/morphology
   api/disambig
   api/tagger
   api/tokenizers
   api/dialectid
   api/sentiment
   api/ner
