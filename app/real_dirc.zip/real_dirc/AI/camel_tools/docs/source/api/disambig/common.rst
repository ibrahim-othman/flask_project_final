camel_tools.disambig.common
===========================

.. automodule:: camel_tools.disambig.common

Classes
-------

.. autoclass:: camel_tools.disambig.common.ScoredAnalysis
.. autoclass:: camel_tools.disambig.common.DisambiguatedWord
.. autoclass:: camel_tools.disambig.common.Disambiguator
   :members: