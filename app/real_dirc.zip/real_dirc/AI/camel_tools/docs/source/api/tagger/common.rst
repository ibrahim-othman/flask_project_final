camel_tools.tagger.common
=========================

.. automodule:: camel_tools.tagger.common


Classes
-------

.. autoclass:: camel_tools.tagger.default.Tagger
   :members:
