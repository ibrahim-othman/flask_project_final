camel_tools.tokenizers
======================

.. automodule:: camel_tools.tokenizers

.. toctree::
   :maxdepth: 1
   :caption: Modules:

   tokenizers/word
   tokenizers/morphological
