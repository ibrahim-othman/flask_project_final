camel_tools.tokenizers.word
===========================

.. automodule:: camel_tools.tokenizers.word

Functions
---------

.. autofunction:: camel_tools.tokenizers.word.simple_word_tokenize
