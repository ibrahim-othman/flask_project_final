camel_tools.utils.stringutils
=============================

This submodule contains a collection of useful helper functions when working
with strings.

Functions
---------

.. autofunction:: camel_tools.utils.stringutils.isunicode

.. autofunction:: camel_tools.utils.stringutils.force_unicode

.. autofunction:: camel_tools.utils.stringutils.force_encoding
