Command-line Tools
==================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   cli/camel_data
   cli/camel_transliterate
   cli/camel_arclean
   cli/camel_word_tokenize
   cli/camel_dediac
   cli/camel_diac
   cli/camel_morphology
