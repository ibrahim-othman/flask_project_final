Overview
========

About
-----

CAMeL Tools is a suite of Arabic natural language processing tools developed by
the
`CAMeL Lab <https://nyuad.nyu.edu/en/research/faculty-research/camel-lab.html>`_
at `New York University Abu Dhabi <http://nyuad.nyu.edu/>`_.

See :doc:`getting_started` for more information.

License
-------

CAMeL Tools is available under the MIT license.
See :doc:`license` for more information.
